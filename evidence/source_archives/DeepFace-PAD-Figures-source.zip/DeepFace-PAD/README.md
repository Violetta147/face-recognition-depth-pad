# DeepFace PAD

Greenfield research project for RGB face presentation attack detection using pseudo-depth supervision.

The implementation follows the research protocol rather than a product-style recognition pipeline.

## Research question

> Can a lightweight classifier learned on a predicted depth map improve CDCN over fixed mean-depth scoring without materially increasing inference cost?

## Documents

- [Research specification](DAC_TA_HE_THONG_NHAN_DIEN_KHUON_MAT_PAD_DEPTH_MAP.md)
- [Rounds 1-4 audit and continuation conditions](reports/RESEARCH_AUDIT_ROUNDS_1_4_2026-10-16.md)
- [Round 5 CASIA preregistration and execution guide](reports/ROUND_5_CASIA_RUNBOOK.md)
- [Round 5 GPU smoke verification](reports/ROUND_5_SMOKE_AUDIT_2026-10-16.md)
- [Round 5 full validation and pre-test freeze](reports/ROUND_5_FULL_VALIDATION_2026-10-16.md)
- [Round 5 frozen test and paired-error results](reports/ROUND_5_TEST_RESULTS_2026-10-16.md)
- [Round 6 replication design and compute options](reports/ROUND_6_REPLICATION_PLAN.md)
- [Run-all notebook for report and slide figures](reports/FIGURE_NOTEBOOK_GUIDE.md)
- [Two-person alternating report plan](KE_HOACH_THUC_HIEN_THEO_BUOI_HOC.md)
- [Dataset and protocol decision](data/README.md)
- [Colab execution runbook](COLAB.md)
- [Literature matrix for round 1](reports/LITERATURE_MATRIX.md)
- [Frozen CASIA E0 result](reports/CASIA_E0_BCE_5E_seed42_summary.md)
- [Audit of rounds 1-3](reports/MIDTERM_ROUNDS_1_3_AUDIT.md)
- [Midterm handoff and required Colab evidence](reports/MIDTERM_ROUNDS_1_3_HANDOFF.md)
- [Round 4: frozen head on the official E1 checkpoint](reports/ROUND_4_OFFICIAL_DEPTH_HEAD.md)
- [Round 4 E2 result reported from Colab](reports/CASIA_E2_OFFICIAL_HEAD_FROZEN_seed42_summary.md)
- [Final report workspace](reports/bao_cao_cuoi_ky/README.md)
- [Final report checklist and session handoff](reports/bao_cao_cuoi_ky/KE_HOACH_HOAN_THANH.md)
- [Final report scaffold and page allocation](reports/bao_cao_cuoi_ky/ban_thao/BAO_CAO_CUOI_KY_KHUNG.md)
- [Editable final report scaffold in Word](reports/bao_cao_cuoi_ky/ban_thao/BAO_CAO_CUOI_KY_KHUNG.docx)

## Mandatory study

| ID | Configuration | Purpose |
|---|---|---|
| E0 | MobileNetV3 with BCE | Lightweight binary baseline |
| E1 | CDCN depth-only with mean-depth scoring | Depth-supervised baseline |
| E2 | CDCN plus frozen learned depth head with BCE | Isolate learned scoring |
| E3 | Official CDCN + learned depth head trained end-to-end with BCE | Test joint optimization |
| E3b | Same model with depth/head/joint stages and BCE | Separate the staged schedule from loss changes |
| E4 | Official CDCN + learned depth head with staged training and Focal Loss | Proposed configuration |

The current continuation keeps the exact CASIA-FASD dataset and subject-disjoint development protocol used by Official E1/E2. It is not an official paper-comparison protocol. Primary metrics are video-level APCER, BPCER, ACER, EER and ROC AUC. It also reports parameter count, model size, latency and FPS.

## Build order

```text
Literature and protocol
    -> dataset manifests and leakage checks
    -> PAD metrics
    -> E0 binary baseline
    -> pseudo-depth generation
    -> E1 CDCN reproduction
    -> E2 to E4 controlled modifications
    -> multiple seeds and paper comparison
    -> error analysis
    -> optional webcam and ArcFace integration
```

## Current status

- [x] Research scope rewritten for a two-person lean study.
- [x] Alternating A/B report schedule defined.
- [x] Recent related work and evaluation rules documented.
- [x] The 22-slide rounds 1-4 deck, speaker narrative and evidence tests are available; presentation/submission status is separate.
- [x] Previous implementation and artifacts removed.
- [x] Temporary midterm dataset and subject-disjoint CASIA development protocol recorded.
- [x] On 16 October, continuation was explicitly fixed to the existing CASIA E1/E2 data; old OULU/Replay access requests are not a blocker for this sequence.
- [x] Reproducible Python package and experiment configs created.
- [x] Manifest leakage validator and metric tests implemented.
- [x] Resumable pseudo-depth queue, status ledger, QA audit, and failure reporting implemented.
- [x] E0 MobileNetV3 baseline implemented.
- [x] Resumable 3DDFA V2 worker implemented.
- [x] Official CDCN CVPR 2020 architecture/loss ported with pinned-source provenance
      and a numerical equivalence verifier.
- [x] E1-to-E2 checkpoint transfer and staged-training code covered by unit tests.
- [x] Official-CDCN E1 run completed and frozen.
- [x] Legacy Lite/Pilot executable model, configs and combined notebook removed.
- [x] E2 has a complete CASIA integration run.
- [x] Stage selection corrected and clean Round 5 configs/notebook prepared for E3/E3b/E4; CPU tests pass.
- [x] E3/E3b/E4 GPU smoke checked: stage checkpoints, frozen backbone in head stages, validation-only scoring.
- [x] E3/E3b/E4 completed 16-epoch full validation; artifacts independently audited and E3 selected by the preregistered validation rule.
- [x] All three runs frozen before test in `comparison_freeze.json` on Drive.
- [x] E3/E3b/E4 development-test scores audited against freeze and historical E0/E1/E2: new variants do not reduce seed-42 ACER versus E1/E2.
- [x] Official-backbone frozen E2 run reported from Colab on 1 October 2026:
      same ACER and same five false-rejected live videos as E1. The summary
      is now independently checked against saved Drive CSV/JSON and checkpoint bytes; no retraining was performed.
- [ ] Independent official benchmark protocol evaluated (outside the current CASIA continuation).
- [x] Temporary CASIA-FASD debug manifest created and leakage-validated (600 videos,
      12,000 uniformly sampled frames).
- [x] CASIA E0 five-epoch baseline completed and test result frozen.
- [x] Full E0-E4 (plus E3b) seed-42 runs completed; multi-seed evidence remains pending.

## Quick start

For the current continuation, start with
`notebooks/Face_PAD_Round5_CASIA_E3_E4.ipynb` and stop at CPU preflight cell 1.5.
Use the supplied committed-source ZIP; the commands below are generic setup,
not instructions to rebuild the existing E1/E2 data or retrain completed runs.

```bash
python -m venv .venv
source .venv/bin/activate  # Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
pytest -q
python scripts/validate_manifest.py data/manifests/all.csv --data-root /content/data
python scripts/generate_depth.py data/manifests/all.csv --data-root /content/data --output-root /content/data/depth
python scripts/run_3ddfa_worker.py --pending /content/data/depth/3ddfa_pending.csv --ledger /content/data/depth/depth_status.csv --3ddfa-root /content/3DDFA_V2 --mode gpu
python scripts/visualize_depth_targets.py --ledger /content/data/depth/depth_status.csv --output reports/depth-smoke.png
python scripts/materialize_depth_manifest.py data/manifests/all.csv --ledger /content/data/depth/depth_status.csv --data-root /content/data --output data/manifests/all-with-depth.csv
python scripts/verify_depth_provenance.py --source data/manifests/all.csv --ledger /content/data/depth/depth_status.csv --derived data/manifests/all-with-depth.csv
python scripts/validate_manifest.py data/manifests/all-with-depth.csv --data-root /content/data --require-depth
python scripts/audit_depth.py data/manifests/all-with-depth.csv --data-root /content/data --report reports/depth-qa.json
python scripts/run_experiment.py configs/e0_mobilenet.yaml
# After an E1 run is frozen:
python scripts/visualize_depth_cases.py --run-dir runs/<E1_RUN_ID> --split val --count 10
python scripts/score_checkpoint.py --run-dir runs/<E1_RUN_ID> --split test
```

All configurations use validation data to select the operating threshold. Test scores
must only be evaluated after the configuration is frozen. E2 requires the E1 checkpoint
path in `training.init_checkpoint`; it fails instead of silently training a head on a
random frozen backbone.
For a comparison with the corrected official E1, use
`configs/casia_e2_official_head_frozen.yaml` and `cdcn_official_head`.
All E1-E4 templates now use the official backbone. Removed pilot model names fail explicitly.
`DepthHead` is a separate module; its 1,265 parameters and checkpoint keys are unchanged.
The official wrapper freezes BatchNorm statistics as well as parameters during
head-only training; E1 and E2 must produce identical depth maps.
The clean `notebooks/Face_PAD_Round4_Official_Frozen_Head_Clean.ipynb` restores the E1
inputs, trains E2, and exports the paired development comparison and efficiency.
Depth-supervised runs also perform manifest preflight before creating a run: every
bona fide sample must reference an existing pseudo-depth target. Empty attack depth
paths remain valid because their protocol target is an all-zero map.
E1, E3, and E4 additionally require `data.source_manifest` and `data.depth_ledger`
in their configs. Training verifies the derived manifest provenance sidecar against
those exact files before creating a run directory, so the byte-level check cannot be
accidentally skipped when starting a paid run. `data.depth_provenance` may point to a
non-default sidecar path when needed. The same preflight then audits every referenced
depth artifact before creating a run directory, so a map changed in place after
materialization cannot bypass validation. Bona fide maps must be readable, finite,
two-dimensional and non-zero, while explicit attack maps must be zero. Each accepted
depth-supervised run stores `depth_input_snapshot.json` with the verified provenance,
full QA result, and SHA-256 plus byte size of every explicit depth target. This makes
the exact pseudo-depth state used at startup auditable even if the shared cache later
changes. Run the
standalone audit before E1 when a JSON report is needed; it records the bona fide
reconstruction failure rate by split and class-level depth statistics.
Pseudo-depth preparation is resumable: `depth_status.csv` records pending, complete,
and failed samples, while `3ddfa_pending.csv` contains only work still requiring
3DDFA V2. Import a worker failure CSV with `--failure-report`; failed bona fide rows
stay failed until `--retry-failed` is explicitly requested and are never replaced by
zero maps.
After the ledger is complete, materialize a separate manifest with verified depth
paths. The command refuses pending or failed rows, invalid artifacts, stale ledger
entries, and outputs outside the configured data root; it never edits the official
source manifest. It also writes `<output>.provenance.json` with SHA-256 checksums for
the exact source manifest, ledger, and derived manifest bytes. Verify that sidecar
after copying or resuming in Colab, then use the derived manifest for the depth audit
and E1/E3/E4 configs.

For Colab Pro setup and the 300-credit budget guardrails, see [COLAB.md](COLAB.md).

## Next deliverables

Rounds 1-4 have reported CASIA development results. Official-CDCN E1 was selected on validation and
scored once on locked test. The clean correction runbook is
`notebooks/Face_PAD_Official_CDCN_E1_Clean.ipynb`. The original executed notebook and all
biometric artifacts remain private on Google Drive.

1. Keep the full final-report workspace paused and preserve the completed seed-42 runs.
2. Retain the Round 5 negative primary result: E3/E3b ACER 5%, E4 4.4444%, versus E1/E2 2.7778%.
3. Confirm available GPU time for Round 6, then preregister matched E1/E3 replication pairs; E3 remains the validation-selected candidate.
4. Complete multi-seed evidence, cost/paper comparison and the remaining visual error analysis/webcam work before the final research freeze.

The CASIA continuation configs are `configs/casia_e3_joint_bce.yaml`,
`configs/casia_e3b_staged_bce.yaml` and `configs/casia_e4_staged_focal.yaml`.
Generic `e3_joint_bce.yaml`/`e4_staged_focal.yaml` files remain historical templates.
The new configs use the same E1 initializer and 16 epochs each. In head/joint
stages `training.selection_metric: classification_bce` selects checkpoints by
the same validation BCE criterion for BCE and Focal; depth warm-up uses depth
loss. `val_selection_loss` is logged separately from the training objective.

## Scope limits

The following are postponed until the experiment table is complete:

- Face-recognition UI and enrollment.
- ArcFace integration.
- Web, mobile, API, cloud or database work.
- Complex tracking.
- Transformer, rPPG and temporal-network experiments.
- Cross-dataset evaluation.

Webcam and ArcFace may be added at the end as a small integration demo. They are not the research contribution.

## Data and privacy

- Do not commit raw datasets, extracted biometric frames, pseudo-depth caches or model weights.
- Follow the official dataset license and protocol.
- Pseudo-depth is not sensor depth.
- Zero-depth spoof labels apply to the selected print/replay setting and do not support claims about 3D masks.
- Test data is used only after configuration and threshold selection are frozen.


## Model cleanup audit

See [Official backbone audit and pilot removal](reports/OFFICIAL_BACKBONE_CLEANUP.md).
Historical results remain in audit reports and Git history; they are not active experiments.
