# Không gian làm báo cáo cuối kỳ

**Tạm dừng từ 16/10/2026 theo yêu cầu người dùng:** chưa điền tiếp các khối báo cáo. Chuyển sang rà soát và hoàn thành thí nghiệm theo kế hoạch 8 lượt, giữ CASIA của E1/E2. Khối 1 và bản thảo đã làm được giữ nguyên; xem [rà soát nghiên cứu](../RESEARCH_AUDIT_ROUNDS_1_4_2026-10-16.md).

Mở [kế hoạch và bối cảnh phiên làm việc](KE_HOACH_HOAN_THANH.md) trước khi bắt đầu.
Báo cáo yêu cầu 15–20 trang; khung hiện được phân bổ 18 trang tính cả các phần đầu
và cuối. Đây là tài liệu học phần cần hoàn thiện cho buổi báo cáo 07h00 ngày
16/10/2026, phòng E2.105, theo lịch người dùng cung cấp.

## File làm việc

| File hoặc thư mục | Dùng để làm gì |
| --- | --- |
| [KE_HOACH_HOAN_THANH.md](KE_HOACH_HOAN_THANH.md) | Bối cảnh, quyết định, thứ tự công việc và checklist |
| [Bản thảo Word](ban_thao/BAO_CAO_CUOI_KY_KHUNG.docx) | Điền nội dung báo cáo |
| [Nguồn Markdown](ban_thao/BAO_CAO_CUOI_KY_KHUNG.md) | Sửa bố cục và nội dung có thể quản lý bằng Git |
| [HUONG_DAN_KHUNG.md](HUONG_DAN_KHUNG.md) | Định dạng, ngân sách trang và cách dựng lại |
| [Bảng bằng chứng](BANG_BANG_CHUNG.md) | Số liệu E0/Official E1/E2 đã đối chiếu, ngưỡng, lỗi, epoch và giới hạn nguồn |
| [Danh mục nguồn](nguon/DANH_MUC_NGUON.md) | Tìm đúng notebook, báo cáo, config, hình và tài liệu |
| `nguon/` | Bản sao tài liệu và notebook để đọc tại một chỗ |
| `hinh_anh/` | Sơ đồ, screenshot kết quả và hình trích từ notebook |
| `tham_khao/` | Slide cũ, lời nói và template slide của môn |

Ba file khung đã được chuyển vào thư mục này. Các notebook, báo cáo kết quả và
config được sao chép để tham chiếu; bản gốc trong repository tiếp tục là nguồn
đối chiếu khi có cập nhật. File `nguon/NGUON_CUC_BO.json` ghi đường dẫn nguồn,
đích và SHA-256 của các bản sao trên máy này.

Gói cục bộ hiện có 37 file tham chiếu, đã kiểm tra checksum sau khi sao chép.
File Word được chuyển nguyên trạng, giữ bản đã cập nhật mục lục và xem 18 trang.

Các bản sao notebook, hình và tài liệu tham khảo cục bộ được Git ignore để không
đưa output sinh trắc học hoặc tài liệu nhóm khác lên repository. Khi mở thư mục
trên máy khác sau khi clone Git, đọc danh mục nguồn để tìm hoặc bổ sung lại chúng.

## Quy tắc làm việc

1. Hoàn thành một khối trong checklist rồi mới chuyển khối tiếp theo.
2. Chỉ đánh dấu hoàn thành khi đoạn viết, bảng hoặc hình đã có trong bản thảo.
3. Cập nhật Word và Markdown sau mỗi khối; tránh hai bản chứa số liệu khác nhau.
4. Kiểm tra đúng run và đơn vị metric trước khi điền số.
5. Sau khi chèn nội dung, cập nhật mục lục và xem lại số trang thực tế trong Word.
6. Commit từng thay đổi hoàn chỉnh theo AGENTS.md; push hoặc nộp Drive khi người
   dùng yêu cầu. Chưa có báo cáo hoàn chỉnh được upload trong phiên tổ chức này.

## Tiến độ ngày 15 tháng 10

Khối 1 đã có bảng bằng chứng từ output notebook cục bộ. Word và Markdown đã
điền bảng test 4.2, ghi validation riêng và epoch được chọn; các phần hướng dẫn
còn lại vẫn là khung. Chưa đọc lại raw artifact trên Drive và chưa upload.
