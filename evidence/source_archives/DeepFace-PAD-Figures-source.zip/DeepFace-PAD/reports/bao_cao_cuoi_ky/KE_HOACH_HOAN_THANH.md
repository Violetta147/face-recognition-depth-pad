# Kế hoạch hoàn thành báo cáo cuối kỳ

**Tạm dừng từ 16/10/2026 theo yêu cầu người dùng:** chưa điền tiếp các khối báo cáo. Chuyển sang rà soát và hoàn thành thí nghiệm theo kế hoạch 8 lượt, giữ CASIA của E1/E2. Khối 1 và bản thảo đã làm được giữ nguyên; xem [rà soát nghiên cứu](../RESEARCH_AUDIT_ROUNDS_1_4_2026-10-16.md).

Cập nhật bối cảnh ngày 15/10/2026, múi giờ Việt Nam. Người viết tiếp cần đọc mục
1–5 trước, rồi chọn một khối chưa hoàn thành ở mục 6. Mục tiêu hiện tại là hoàn
thiện báo cáo Word dài 15–20 trang để phục vụ buổi báo cáo sáng 16/10.

## 1 Bối cảnh từ chiều 15 tháng 10

Người dùng gửi file `C:/Users/LAPTOP T&T/Downloads/CK/docsFASobsidian/Tổng hợp chat zalo.md`.
Đây chính là bản tổng hợp lịch sử Zalo mà người dùng muốn dùng làm căn cứ. Không
yêu cầu người dùng cung cấp lại một lịch sử Zalo khác chỉ vì đây là bản tổng hợp.

- Theo người dùng, lúc 17h41 thầy nhắn: “nhiều nhóm chưa làm đc nhiều b cáo cuối
  kỳ nên hoãn tối nay, các nhóm tiếp tục hoàn thiện”. Buổi tối dự kiến lúc 19h.
- Người dùng cho rằng thầy có thể đã kiểm tra bài nộp. Đây là suy đoán có cơ sở
  từ tình huống, chưa có log xác nhận thầy đã mở thư mục của nhóm.
- Ảnh Drive hiển thị thư mục nhóm với mốc 17h49 ở cột ngày sửa. Người dùng nói
  vừa tạo thư mục; không dùng mốc này để khẳng định thời điểm thầy kiểm tra.
- Ảnh danh sách phân nhóm ghi nhóm 1 báo cáo **07h00 ngày 16/10, phòng E2.105**.
  Hoãn tối 15/10 không đồng nghĩa hủy lịch này.
- Thành viên: **Trịnh Minh Đạt, MSSV 102230180** và **Nguyễn Hữu Minh Quân,
  MSSV 102230208**.
- Tên đề tài đăng ký trên ảnh: “Hệ thống nhận diện khuôn mặt thời gian thực tích
  hợp chống giả mạo (Silent Face Anti-Spoofing) dựa trên bản đồ độ sâu (Depth Map)”.
  Phần nghiên cứu đã làm tập trung vào PAD; phải mô tả đúng phạm vi hoàn thành.

### Nơi nộp và các tài liệu khác nhau

| Nội dung | Thông tin đã xác nhận |
| --- | --- |
| Slides báo cáo mỗi buổi | https://drive.google.com/drive/folders/1QmQeqk5tlgWkhYMCUG0KR49PDNXyuFJf |
| Thư mục Sinh viên upload Article | https://drive.google.com/drive/folders/1KOLi_87f1561w39hwEklD2zJtVflD8by |
| Thư mục nhóm trong Article | https://drive.google.com/drive/folders/1XZO_bhblN-yTcbhkrV79GvD1p4qH-BXb |
| Báo cáo Word hiện tại | Bản tổng hợp ghi phải làm bản Word hiện tại của báo cáo cuối cùng, upload trước buổi hướng dẫn 19h |
| Paper hoặc Article | Người dùng xác nhận đây là bài báo viết theo hướng nghiên cứu khoa học, thầy yêu cầu thêm; chưa phải nhiệm vụ đang làm |
| Mẫu Word | Người dùng xác nhận thầy chưa gửi file Word mẫu |
| Mẫu slide | Thầy yêu cầu Template-DUT-Total.pptx cho các báo cáo từ nay |
| Mốc paper trong bản tổng hợp | 07h00 ngày 01/11/2026; chưa suy diễn thành hạn của bản Word hiện tại |

Các nhóm đã nộp cả tài liệu mang cấu trúc báo cáo học phần trong thư mục Article.
Đây là bằng chứng về cách các nhóm đang sử dụng thư mục, không đủ để khẳng định
mọi file ở đó là cùng một loại tài liệu. Khi nộp, người dùng chọn đúng file và nơi
nộp theo chỉ dẫn hiện hành. Phiên này chưa upload báo cáo lên Drive.

### Những hiểu nhầm cần tránh lặp lại

Trợ lý từng tự suy diễn rằng phải làm hai bản Word riêng ngay lúc này, sau đó
diễn giải thiếu nhất quán giữa báo cáo và article. Người dùng đã chỉnh rõ: hiện
tại chỉ làm **báo cáo cuối kỳ**; paper sẽ có hướng nghiên cứu khoa học và là yêu
cầu thêm. Không chuyển sang viết paper hoặc tự chọn mẫu IEEE khi chưa được yêu cầu.

## 2 Mẫu báo cáo đã chọn và nguồn tham khảo

Đã đọc bố cục ba báo cáo đầu: biển số độ phân giải thấp, biển báo Việt Nam và
té ngã từ skeleton. Theo yêu cầu tiếp theo, đã đọc thêm báo cáo của Hà Đức Kiên
và hai nhóm 22ES. Tổng cộng đã xem bố cục sáu báo cáo; một paper CLIP/Gemma chỉ
được đọc để phân biệt dạng tài liệu, không dùng làm mẫu báo cáo hiện tại.

| Nguồn chọn bố cục | Cấu trúc và phần học hỏi |
| --- | --- |
| Hà Đức Kiên và Huỳnh Thảo Nhi, MS-ILA | Bìa, phân công, tóm tắt, mục lục; 4 chương gồm bài toán, dữ liệu, phương pháp, kết quả; kết luận riêng |
| Nhóm 08, 22ES, phân loại rác | 7 chương; giải thích lựa chọn giải pháp và so sánh với nghiên cứu trước |
| Nhóm 2, 22ES, lá cà chua | 10 mục chính; phân biệt giai đoạn huấn luyện, đánh giá, lỗi, giới hạn và minh chứng tái lập |

Link ba nguồn nằm trong `HUONG_DAN_KHUNG.md`. Shortcut MS-ILA trong thư mục Nhóm
8 ban đầu không fetch được; sau đó đã tìm và đọc Google Doc gốc có tên “BÁO CÁO
FINAL - MS-ILA - THỊ GIÁC MÁY TÍNH”, có tên Hà Đức Kiên và Huỳnh Thảo Nhi.

### Cấu trúc chốt cho nhóm

1. Phần đầu: bìa, tóm tắt, phân công/đóng góp, mục lục, danh mục hình/bảng.
2. Chương 1: Tổng quan bài toán và hướng nghiên cứu.
3. Chương 2: Dữ liệu và quy trình xử lý.
4. Chương 3: Phương pháp và triển khai.
5. Chương 4: Thực nghiệm và đánh giá.
6. Kết luận và hướng phát triển.
7. Tài liệu tham khảo và phụ lục minh chứng/tái lập.

Mẫu này là lựa chọn làm việc của nhóm, chưa phải mẫu chính thức do thầy ban hành.
Tách dữ liệu thành chương riêng và đặt kết luận sau bốn chương nội dung.

### Ngân sách 18 trang của khung

| Trang | Phần |
| --- | --- |
| 1 | Bìa |
| 2 | Tóm tắt và đóng góp |
| 3 | Mục lục và danh mục hình/bảng |
| 4–5 | Chương 1 |
| 6–8 | Chương 2 |
| 9–12 | Chương 3 |
| 13–16 | Chương 4 |
| 17 | Kết luận và hướng phát triển |
| 18 | Tài liệu tham khảo và phụ lục ngắn |

Yêu cầu người dùng là **15–20 trang**. Phân bổ đang tính cả bìa, mục lục, tài liệu
tham khảo và phụ lục; đây là giả định làm việc đã nêu, không phải xác nhận quy định
đếm trang của thầy. Sau khi điền, điều chỉnh ngắt trang theo nội dung thật. Không
giữ trang trống để đạt số lượng và không phải viết đủ 18 trang nội dung mới.

Định dạng: A4 một cột, Times New Roman 13 pt, giãn dòng 1,3, lề trái 3 cm, các lề
còn lại 2 cm; bảng 11 pt, tiêu đề chương 16 pt và đề mục 14 pt. Mục lục tự động.

## 3 Trạng thái file và các việc đã hoàn thành

- [x] Đọc bản tổng hợp Zalo và ảnh lịch báo cáo.
- [x] Ghi nhận yêu cầu 15–20 trang và phân biệt báo cáo hiện tại với paper.
- [x] Đối chiếu bố cục báo cáo của Hà Đức Kiên và các nhóm khác.
- [x] Tạo khung Word và Markdown, có đề mục, hướng dẫn, bảng trống, chỗ chèn hình.
- [x] Cập nhật mục lục bằng Microsoft Word; bản khung phân trang thành 18 trang.
- [x] Xem bản render của đủ 18 trang; sửa font và bỏ đường viền xanh ở tiêu đề.
- [x] Tạo test khung báo cáo; test unittest đã chạy thành công.
- [x] Chuyển bản thảo và hướng dẫn vào thư mục `reports/bao_cao_cuoi_ky/`.
- [x] Tạo kế hoạch/checklist này và danh mục nguồn cho phiên mới.
- [ ] Điền nội dung hoàn chỉnh vào từng phần của báo cáo.
- [ ] Xác nhận phân công thực tế, giảng viên, khoa và mã lớp còn trống trên bìa.
- [ ] Rà bản báo cáo hoàn chỉnh và cập nhật slides theo template của môn nếu cần.
- [ ] Nộp các file đã hoàn thành theo yêu cầu hiện hành.

Commit tạo khung trước khi gom thư mục là `25c6654`. Mã nguồn dựng khung vẫn ở
`scripts/build_final_report_scaffold.py`; test ở `tests/test_final_report_scaffold.py`.
Commit tổ chức thư mục và kế hoạch được tạo khi kết thúc phiên này; xem `git log`.
Chưa có yêu cầu push các thay đổi mới của ngày 15/10. Lần push đã xác nhận trước
đó là tới `a62683b`; nếu cần trạng thái hiện tại của GitHub phải kiểm tra remote.

Khung có nhiều đoạn `[hướng dẫn]` và ô `[Điền]`. Không gọi khung này là báo cáo
hoàn chỉnh hoặc file đã sẵn sàng nộp. Những thông tin phân công chưa được xác nhận
được để trống, không suy ra từ tên người hoặc lịch sử prompt.

## 4 Bối cảnh nghiên cứu cần giữ khi viết

PAD phân biệt mẫu khuôn mặt thật và tấn công trình diện. Nhận diện danh tính là
nhiệm vụ xác định người đó là ai. Nghiên cứu hiện tập trung vào PAD từ ảnh RGB
với nhãn độ sâu suy ra. Giới thiệu thuật ngữ trước khi dùng ký hiệu hoặc viết tắt.

| Ký hiệu | Vai trò đã làm |
| --- | --- |
| E0 | MobileNetV3-Small phân loại trực tiếp RGB; mô hình tham khảo |
| E1 | Official CDCN dự đoán bản đồ độ sâu và lấy trung bình bản đồ thành điểm |
| E2 | Nạp checkpoint Official E1, cố định backbone và thống kê BatchNorm, chỉ học head đọc bản đồ |
| E3/E4 | Các hướng tiếp theo trong plan; chưa có kết quả benchmark trong bộ bằng chứng này |

Phép so sánh chính là E1–E2. E0 nằm trong bảng tổng quan để có bối cảnh. E0–E1
khác kiến trúc, loss và tiền xử lý nên không cô lập được riêng tác dụng của depth.
Không dùng E1-Lite Pilot trong bảng kết quả chính; code pilot đã được dọn ở
commit `eb8ba8c`. Một số tài liệu lịch sử vẫn nhắc pilot và phải đọc đúng phần.

E1 giữ topology và official depth loss từ mã tác giả CDCN, khóa commit
`fd8370e8f32bdd090a3552f5a1fe4c301fa99f2b`. Kiểm tra đã ghi nhận 73 tensor và
`max_abs_error=0.0`. Điều này hỗ trợ tái lập kiến trúc/loss trong điều kiện nhóm;
không có nghĩa đã tái lập số benchmark gốc hoặc mô hình SOTA mới nhất.

CDCN++ và các hướng mới hơn tồn tại; chưa được nhóm chạy trong các run nêu ở đây.
Ý tưởng classifier đọc predicted depth có tiền lệ trong UCDCN; tránh tuyên bố
ý tưởng chung này là hoàn toàn mới. Tìm nguồn gốc khi viết nghiên cứu liên quan.

### Số liệu hiện có để đối chiếu trước khi điền

Các giá trị sau đã xuất hiện trong output notebook và hồ sơ làm slide. Chúng
giúp tìm đúng run; khi viết phải đối chiếu lại nguồn, đơn vị và split.

| Mô hình | APCER % | BPCER % | ACER % | EER % | AUC |
| --- | --- | --- | --- | --- | --- |
| E0 | 0,0000 | 11,1111 | 5,5556 | 2,4074 | 0,997984 |
| Official E1 | 0,0000 | 5,5556 | 2,7778 | 2,2222 | 0,994444 |
| E2 frozen head | 0,0000 | 5,5556 | 2,7778 | 2,2222 | 0,994321 |

CASIA development test, đánh giá theo video, seed 42: 270 attack, 90 live,
tổng 360 video. Hai ngưỡng của E1/E2 lấy từ validation, lần lượt 0,19160388 và
0,41177915. E1/E2 cùng đúng 355 và cùng sai 5 video live; E2 sửa 0 lỗi và tạo 0 lỗi
mới tại các ngưỡng đó. Head thêm 1.265 tham số; checkpoint E2 được chọn ở epoch 1
bằng validation BCE. Head đã học được điểm, nhưng cấu hình này chưa giảm ACER.

Dữ liệu dự kiến theo manifest đã dùng: 50 người, 600 video, 12.000 frame;
train 16 người/192 video/3.840 frame, validation 4/48/960, test 30/360/7.200.
Có 3.000 frame thật với pseudo-depth và 9.000 attack với zero map. Pseudo-depth
là nhãn được tạo trước; 3DDFA V2 không cần chạy trong suy luận E1/E2.

Giới hạn phải giữ: một seed, protocol phát triển của nhóm, test đã được quan sát,
chưa có xác nhận độc lập hoặc cross-dataset. Latency A100 đo riêng forward của
mô hình; không coi đó là tốc độ toàn hệ thống hoặc bằng chứng E2 nhanh hơn.

### Run và nguồn chính

- E0: `CASIA_E0_BCE_5E_seed42_20260920T082941Z`.
- E1: `CASIA_E1_CDCN_OFFICIAL_seed42_20260921T114029Z`.
- E2: `CASIA_E2_CDCN_OFFICIAL_HEAD_FROZEN_seed42_20261001T155213Z`.
- E1 checkpoint SHA-256:
  `679810c001e526cafed8685fe731a7d5c539fd3fb9c5a9fb31725b7dbdf57024`.
- Runs trên Colab/Drive: `/content/drive/MyDrive/face-pad/runs/`.
- Dataset Colab: `/content/datasets/casia-fasd`.
- Depth QA E2: `/content/drive/MyDrive/face-pad/reports/casia-depth-qa-round4.json`.
- Danh mục notebook, báo cáo, hình và config: `nguon/DANH_MUC_NGUON.md`.

Raw CSV/JSON/checkpoint trên Drive chưa được tải và kiểm toán mới trong phiên
này. Không mô tả các phép kiểm tra đó là vừa hoàn thành. Các yêu cầu phê duyệt
OULU-NPU/Replay-Attack trong tài liệu tháng 9 cần kiểm tra lại nếu muốn cập nhật
tình trạng hiện tại; không tự suy ra là vẫn chờ hoặc đã được cấp.

## 5 Cách chia công việc giữa người viết và Codex

Đây là cách phối hợp cho việc sắp làm, không phải mô tả đóng góp lịch sử của hai
thành viên. Người dùng chọn từng khối, đọc và xác nhận nội dung; Codex đọc nguồn,
soạn đoạn, lập bảng, chèn hình và kiểm tra định dạng. Thành viên còn lại xác nhận
phần đã làm của mình và rà phần được giao. Chỉ điền tên chịu trách nhiệm sau khi
nhóm thống nhất; không tự gán Quân hoặc Đạt đã thực hiện một thí nghiệm.

Một khối được xem là hoàn thành khi: nội dung đã có trong bản thảo, nguồn số liệu
đã ghi, hình/bảng đúng mẫu và người dùng đã hiểu kết luận. Cập nhật checklist sau
mỗi khối. Giữ Word/Markdown đồng bộ; trước khi dựng lại từ Markdown, kiểm tra xem
Word có chỉnh sửa thủ công nào chưa chuyển sang nguồn hay không.

## 6 Checklist theo thứ tự thực hiện

### Khối 0 Xác nhận đầu vào còn thiếu

- [ ] Điền khoa, giảng viên và mã lớp từ nguồn chính xác.
- [ ] Hai thành viên xác nhận công việc thực tế và minh chứng từng việc.
- [ ] Kiểm tra có run hoặc kết quả mới sau E2 hay không; nếu không, giữ phạm vi E0/E1/E2.
- [ ] Chọn bản Word đang làm và cách đồng bộ với Markdown.

Hoàn thành khi bìa và bảng đóng góp không còn thông tin phải đoán. Các thông tin
còn thiếu không chặn việc viết dữ liệu và phương pháp đã có bằng chứng.

### Khối 1 Khóa bảng bằng chứng trước khi viết số

- [x] Đọc output E0, Official E1, E2; xác nhận run ID, checkpoint, seed và split.
- [x] Ghi lại bảng validation và test riêng, ngưỡng, số video và số lỗi.
- [x] Đối chiếu metric phần trăm với dạng 0–1 trong các báo cáo cũ.
- [x] Xác nhận best epoch E0/E1/E2 và nguồn training curve.
- [x] Ghi nguồn của từng con số và điểm chưa xác minh vào ghi chú bản thảo.

Hoàn thành khi có một bảng nguồn thống nhất đủ để điền Chương 4, không lẫn Lite,
validation với test hoặc checkpoint cuối với checkpoint được chọn.

Đã đối chiếu output cục bộ ngày 15/10/2026; xem [bảng bằng chứng](BANG_BANG_CHUNG.md). Bản thảo Word/Markdown đã điền bảng test, ghi validation riêng, epoch chọn và giới hạn nguồn. Ngưỡng E2 chỉ được xác nhận đến 8 chữ số hiển thị; chưa đọc lại raw CSV/JSON hoặc checkpoint trên Drive. Đây là hoàn thành bảng nguồn cho báo cáo, chưa phải kiểm toán độc lập artifact.

### Khối 2 Viết Chương 2 về dữ liệu và xử lý

- [ ] Viết 2.1 nguồn CASIA-FASD và các loại mẫu.
- [ ] Điền bảng chia tập 2.2; giải thích tách người/video và 20 frame/video.
- [ ] Viết 2.3 lấy frame, kích thước, chuẩn hóa và khác biệt giữa các mô hình.
- [ ] Viết 2.4 nhãn 3DDFA, zero map, mask và phân biệt nhãn với dự đoán.
- [ ] Điền 2.5 kiểm tra chất lượng; ghi đúng báo cáo QA đang dùng.
- [ ] Viết 2.6 manifest và kiểm tra tính nhất quán; chèn hình có nguồn.

Hoàn thành khi người đọc biết mỗi mẫu đến từ đâu, được biến đổi thế nào và tập
nào được dùng để học, chọn cấu hình hoặc đánh giá. Mục tiêu khoảng 3 trang.

### Khối 3 Viết Chương 3 về phương pháp

- [ ] Viết 3.1 và định nghĩa E0/E1/E2 trước khi dùng các ký hiệu đó.
- [ ] Viết E0 RGB và đầu ra một logit; giải thích sigmoid và loss.
- [ ] Viết Official E1, CDC, hợp nhất đa tỉ lệ và mean depth scoring.
- [ ] Viết phạm vi tái lập và kết quả đối chiếu mã tác giả.
- [ ] Viết E2: đúng checkpoint E1, khóa weights/BatchNorm, head và tham số thêm.
- [ ] Viết loss, cấu hình huấn luyện và tiêu chí chọn checkpoint.
- [ ] Viết suy luận, tổng hợp video, chọn ngưỡng validation và khóa trước test.
- [ ] Chèn sơ đồ đã đối chiếu code; chú thích phần minh họa và kích thước.

Hoàn thành khi người đọc có thể lần theo RGB đến quyết định và chỉ ra khác biệt
duy nhất cần kiểm tra trong phép so E1–E2. Mục tiêu khoảng 4 trang.

### Khối 4 Viết Chương 4 về kết quả và phân tích

- [ ] Điền thiết lập, phần cứng, seed và điều kiện so sánh.
- [ ] Giải thích metric và đơn vị, đặc biệt ACER tại ngưỡng đã khóa.
- [ ] Điền bảng E0/E1/E2 từ bảng nguồn ở Khối 1.
- [ ] Viết câu trả lời cho so sánh E1–E2, gồm cả kết quả chưa cải thiện.
- [ ] Chèn curve và đánh dấu best epoch; không so độ lớn hai loại loss khác nhau.
- [ ] Chèn case depth thật từ notebook và ghi đúng validation/test.
- [ ] Điền bảng cùng đúng, sửa lỗi, lỗi mới, cùng sai; kiểm tra tổng 360 video.
- [ ] Phân tích năm video cùng sai bằng bảng; chỉ bổ sung nguyên nhân sau khi xem đúng mẫu.
- [ ] Điền tham số/latency, ranh giới đo và giới hạn của phép đo sơ bộ.
- [ ] Viết giới hạn một seed, test đã quan sát và benchmark chưa độc lập.

Hoàn thành khi mỗi kết luận có bảng, hình hoặc nguồn hỗ trợ; không suy ra head
vô ích nói chung từ một lần thử. Mục tiêu khoảng 4 trang.

### Khối 5 Viết Chương 1 và đặt nghiên cứu trong bối cảnh

- [ ] Viết bài toán PAD trước, rồi phân biệt nhận diện danh tính.
- [ ] Giải thích depth supervision và lý do nghiên cứu cách đọc bản đồ.
- [ ] Nêu mục tiêu, phạm vi hiện tại trong tên đề tài đăng ký.
- [ ] Điền bảng công trình liên quan, nguồn gốc và điều kiện đánh giá.
- [ ] Giải thích lựa chọn CDCN; phân biệt đối chứng đã chạy với phương pháp mới chỉ khảo sát.
- [ ] Viết câu hỏi nghiên cứu và phép so có kiểm soát E1–E2.

Hoàn thành khi người đọc hiểu nhóm muốn kiểm tra điều gì trước khi đọc kỹ thuật.
Mục tiêu khoảng 2 trang. Không chuyển Chương 1 thành một danh sách tên model.

### Khối 6 Viết kết luận và các phần đầu cuối

- [ ] Viết kết luận trực tiếp từ Chương 4, không thêm số hoặc claim mới.
- [ ] Nêu công việc tiếp theo từ giới hạn; E3/E4 chỉ là kế hoạch nếu chưa chạy.
- [ ] Viết tóm tắt sau cùng, khoảng 150–200 từ, gồm mục tiêu, phương pháp, kết quả và giới hạn.
- [ ] Hoàn thiện từ khóa, bảng đóng góp và thông tin bìa.
- [ ] Điền tài liệu tham khảo gốc cho dataset, CDCN, 3DDFA và các nghiên cứu đã dẫn.
- [ ] Điền phụ lục run/config/manifest/checkpoint và hướng dẫn chạy ngắn.

Hoàn thành khi tóm tắt và kết luận nhất quán với bảng kết quả, phần đóng góp được
hai thành viên xác nhận, mọi tài liệu tham khảo đều có chỗ dẫn trong nội dung.

### Khối 7 Đọc lại theo reader first prose

- [ ] Giải thích thuật ngữ và tên viết tắt khi xuất hiện lần đầu.
- [ ] Đọc các đề mục thành một dàn ý; sửa mục quá chung hoặc lặp.
- [ ] Mỗi đoạn có một ý chính và giải thích quan hệ nguyên nhân, điều kiện hoặc so sánh.
- [ ] Tách kết quả quan sát khỏi giả thuyết nguyên nhân và công việc dự kiến.
- [ ] Kiểm tra từng số, mẫu số, đơn vị, chiều tốt hơn và nguồn.
- [ ] Bỏ dấu gạch ngang dài và cách viết đối lập ngắn gây khó hiểu.
- [ ] Thay hết đoạn hướng dẫn/ô trống bằng nội dung; chỗ thiếu bằng chứng được mô tả chính xác.

Hoàn thành khi người chưa tham gia dự án có thể hiểu báo cáo mà không cần người
thuyết trình giải thích mọi ký hiệu hoặc bổ sung điều kiện bị bỏ sót.

### Khối 8 Kiểm tra Word và chuẩn bị nộp

- [ ] Cập nhật mục lục, danh mục hình/bảng, số trang và tham chiếu.
- [ ] Xem đủ các trang; sửa bảng tràn, ảnh méo, tiêu đề rơi cuối trang, chữ quá nhỏ.
- [ ] Kiểm tra tổng 15–20 trang sau khi điền, điều chỉnh dung lượng theo ý nghĩa nội dung.
- [ ] Lưu bản Word hoàn chỉnh với tên nhóm/đề tài dễ nhận biết và kiểm tra mở lại.
- [ ] Nếu chuẩn bị slides sáng mai, dùng Template-DUT-Total và kết quả cùng phiên bản báo cáo.
- [ ] Người dùng xác nhận file và thư mục nộp; upload và đọc lại metadata/file sau khi được yêu cầu.
- [ ] Hai thành viên luyện giải thích phần mình làm và thống nhất phần trình bày.

Hoàn thành khi file cuối có thể mở, nội dung thống nhất và trạng thái nộp được
ghi theo kết quả thực tế. Tạo file chưa đồng nghĩa đã upload.

## 7 Điểm bắt đầu cho phiên làm việc mới

Thư mục project:
`C:/Users/LAPTOP T&T/VIOLETTA/Documents/DeepFace-PAD`.

1. Đọc AGENTS.md, README của thư mục báo cáo và kế hoạch này.
2. Đọc skill `C:/Users/LAPTOP T&T/.agents/skills/reader-first-prose/SKILL.md` theo
   yêu cầu người dùng; áp dụng định nghĩa trước khi dùng và giữ giới hạn bằng chứng.
3. Kiểm tra git status để phân biệt file người dùng đang sửa với phần cần làm.
4. Đọc `ban_thao/BAO_CAO_CUOI_KY_KHUNG.md` để biết đúng các đề mục.
5. Xác nhận đang có khung 18 trang, chưa viết báo cáo hoàn chỉnh. Nêu Khối 1 là
   bước đầu có thể làm ngay; thông tin thiếu ở Khối 0 được hỏi khi cần và không chặn nguồn đã có.
6. Người dùng muốn lần lượt hoàn thành từng phần. Chờ người dùng chọn khối hoặc
   yêu cầu viết; không tự triển khai toàn bộ báo cáo trong lúc chỉ bàn giao chat.

Các thay đổi người dùng đang có trước khi bàn giao: hai notebook Official E1 và
E2 đã sửa, `.obsidian/`, PDF CDCN, thư mục diagrams và template PPTX chưa track.
Không stage, xóa hoặc ghi đè chúng chỉ để làm sạch Git. File Word hiện tại đã
được chuyển nguyên trạng, không dựng lại và thay nội dung khi gom thư mục.

Các commit phải được tạo sau mỗi thay đổi logic hoàn chỉnh theo AGENTS.md.
Nếu sửa code, đồng bộ tài liệu/test và chạy test trước khi chuyển việc. Nếu chỉ
viết báo cáo, kiểm tra nội dung, nguồn và render sau thay đổi bố cục đáng kể.

## 8 Nhật ký tiếp tục

| Phiên | Khối đã hoàn thành | File đã sửa | Việc còn lại |
| --- | --- | --- | --- |
| 15/10 tổ chức và bàn giao | Khung, thư mục, checklist, tóm tắt context | Các file trong thư mục báo cáo | Khối 0–8 chưa viết nội dung hoàn chỉnh |
| 15/10 đối chiếu Khối 1 | Bảng nguồn E0/Official E1/E2; validation/test riêng; ngưỡng, lỗi, epoch và curve | BANG_BANG_CHUNG.md, bản thảo Word/Markdown, README, danh mục nguồn và kế hoạch | Khối 0, 2–8; kiểm toán raw artifact chỉ khi cần độ chính xác sâu hơn |
